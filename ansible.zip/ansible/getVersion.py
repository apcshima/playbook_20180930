from jnpr.junos import Device

Devices = [ { "hostname" : 'vsrx' , "user": 'sgmt' }, ]

for device in Devices:
    dev = Device(host=device["hostname"], user=device["user"], port='22')
    dev.open()
    print "Hostname:{:<10} Version:{}".format( dev.facts["hostname"], dev.facts["version"] )

